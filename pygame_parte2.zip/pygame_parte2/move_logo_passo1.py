#----------------------------------------------------------
#PASSO 1: desenhar a tela do jogo
#----------------------------------------------------------
#1-seção de configuração e definição de variáveis
import pygame, sys
from pygame.locals import * # ** "pygame.locals": submódulo com as constantes da pygame, como QUIT

# CONSTANTES
LARGURA_TELA = 800; ALTURA_TELA = 600; # Constantes para o tamanho da tela
FPS = 200 # Será utilizado para a velocidade do jogo

# Função principal
def main():
    pygame.init()
    global tela  # ** para que a janela do jogo seja tratada com variável global

    FPSCLOCK = pygame.time.Clock()
    #cria a janela do jogo 
    tela = pygame.display.set_mode((LARGURA_TELA,ALTURA_TELA))
    pygame.display.set_caption('Move Logo') # ** põe o título na janela
    
    #2-seção "game loop" ----------------------------
    terminou = False
    while not terminou: #Loop principal do jogo
        #3-seção de tratamento de eventos 
        for event in pygame.event.get():
            if event.type == QUIT:
                terminou = True
        
        #4-atualização da tela do jogo 
        pygame.display.update()
        FPSCLOCK.tick(FPS)

    #---- fim do game loop ---------------------------
    # Finaliza a janela do jogo
    pygame.display.quit()
    # Finaliza o pygame
    pygame.quit()
    sys.exit()


if __name__=='__main__': # ** para chamar a função principal
    main()
