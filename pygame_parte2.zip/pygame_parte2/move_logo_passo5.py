#----------------------------------------------------------
#PASSO 5: incluindo som
#----------------------------------------------------------

#1-seção de configuração e definição de variáveis
import pygame, sys
from pygame.locals import * # ** "pygame.locals": submódulo com as constantes da pygame, como QUIT

# CONSTANTES
LARGURA_TELA = 800; ALTURA_TELA = 600; BORDA = 20 # Constantes para o tamanho da tela
FPS = 200 # Será utilizado para a velocidade do jogo
COR_FUNDO = (102, 205, 170) #cor do fundo da tela
MARROM = (80, 00, 00)       #cor da borda
VERMELHO = (255, 00, 00)    #cor do quadrado 
LADO = 100  #tamanho do lado do quadrado
VELOCIDADE = 2 #velocidade do objeto sendo movimentado na tela


def desenha_arena():
    """pinta a cor de fundo e desenha as bordas da tela"""
    tela.fill(COR_FUNDO)
    pygame.draw.rect(tela, MARROM, ((BORDA,BORDA),(LARGURA_TELA-BORDA*2,ALTURA_TELA-BORDA*2)), 1)


def desenha_figura(x, y, imagem, direcao):
    """desenha a figura na coordenada x, y passada como entrada"""
    #pygame.draw.rect(tela, VERMELHO, (x, y, LADO, LADO))
    tela.blit(imagem, (x, y))
    escreve_texto(direcao)


def escreve_texto(msg):
    #1. cria o objeto Font
    fontObj = pygame.font.Font('freesansbold.ttf', 32)
    
    #2. cria o objeto Surface com o texto desejado
    textSurfaceObj = fontObj.render(msg, True, MARROM)
    
    #3. cria objeto Rect p/ o objeto Surface
    textRectObj = textSurfaceObj.get_rect()              

    #4. altera a posição x,y do objeto Rect.
    #   nesse caso, jogamos para o centro da tela, centralizando o texto
    textRectObj.center = (LARGURA_TELA // 2, ALTURA_TELA // 2) 

    #5. cola (blit) o objeto Surface com o texto na tela
    tela.blit(textSurfaceObj, textRectObj)
 
# ** -------------------------------------------------------------
def move_figura(x, y, direcao, som):
    """
    retorna a próxima coordenada x,y em que a figura deve ser desenhada e
    a direção para onde deve ser movida, considerando as coordenadas x,y atuais
    e a direção atual, passadas como entrada. Toca som quando figura bate em alguma borda.
    """
    if direcao == 'direita':
        x += VELOCIDADE
        #bateu na borda direita? - muda direção para baixo e toca som
        if x >= (LARGURA_TELA - BORDA - LADO): 
            x = (LARGURA_TELA - BORDA - LADO)
            direcao = 'baixo'
            som.play()
    elif direcao == 'baixo':
        y += VELOCIDADE
        #bateu na borda inferior? - muda direção para esquerda e toca som
        if y >= (ALTURA_TELA - BORDA - LADO): 
            y = (ALTURA_TELA - BORDA - LADO)
            direcao = 'esquerda'
            som.play()
    elif direcao == 'esquerda': 
        x -= VELOCIDADE
        #bateu na borda esquerda? - muda direção para cima e toca som
        if x <= BORDA: 
            x = BORDA
            direcao = 'cima'
            som.play()
    elif direcao == 'cima': 
        y -= VELOCIDADE
        #bateu na borda superior? - muda direção para direita e toca som
        if y <= BORDA: 
            y = BORDA
            direcao = 'direita'
            som.play()
    
    return x, y, direcao
# ** -------------------------------------------------------------
        
# Função principal
def main():
    pygame.init()
    global tela  # ** para que a janela do jogo seja tratada com variável global    
 
    FPSCLOCK = pygame.time.Clock()
 
    #cria um objeto do tipo imagem, a partir de um jpg 
    obj_logo = pygame.image.load('logo_100x100.jpg')
    
    # ** -------------------------------------------------------------
    #cria um objeto do tipo som, a partir de um arquivo ogg 
    obj_som = pygame.mixer.Sound('colisao.ogg')   
    # ** -------------------------------------------------------------

    #cria a janela do jogo 
    tela = pygame.display.set_mode((LARGURA_TELA,ALTURA_TELA))
    pygame.display.set_caption('Move Logo') # ** põe o título na janela

    figuraX = BORDA     #controla a posição X da figura (começa de x=20)
    figuraY = BORDA     #controla a posição Y da figura (começa de y=20)
    direcao = "direita" #controla a direção da figura (começa indo para direita)

    desenha_arena()
    desenha_figura(figuraX, figuraY, obj_logo, direcao)
    
    #2-seção "game loop" ----------------------------
    terminou = False
    while not terminou: #Loop principal do jogo
        #3-seção de tratamento de eventos 
        for event in pygame.event.get():
            if event.type == QUIT:
                terminou = True
        
        # ** -------------------------------------------------------------
        #obtem a próxima posição x, y da figura e a próxima direção para onde deve ir
        figuraX, figuraY, direcao = move_figura(figuraX, figuraY, direcao, obj_som)
        # ** -------------------------------------------------------------
        
        
        #redesenha a arena (pinta a tela com a cor de fundo e desenha as bordas)
        desenha_arena()
        
        #redesenha a figura na próxima posição correta,
        #exibindo texto com a direção no centro da tela
        desenha_figura(figuraX, figuraY, obj_logo, direcao)
        
        #4-atualização da tela do jogo 
        pygame.display.update()
        FPSCLOCK.tick(FPS)

    #---- fim do game loop ---------------------------
    # Finaliza a janela do jogo
    pygame.display.quit()
    # Finaliza o pygame
    pygame.quit()
    sys.exit()


if __name__=='__main__': # ** para chamar a função principal
    main()






