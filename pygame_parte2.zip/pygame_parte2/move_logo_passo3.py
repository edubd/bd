#----------------------------------------------------------
#PASSO 3: trocando o quadrado por uma imagem
#----------------------------------------------------------

#1-seção de configuração e definição de variáveis
import pygame, sys
from pygame.locals import * # ** "pygame.locals": submódulo com as constantes da pygame, como QUIT

# CONSTANTES
LARGURA_TELA = 800; ALTURA_TELA = 600; BORDA = 20 # Constantes para o tamanho da tela
FPS = 200 # Será utilizado para a velocidade do jogo
COR_FUNDO = (102, 205, 170) #cor do fundo da tela
MARROM = (80, 00, 00)       #cor da borda
VERMELHO = (255, 00, 00)    #cor do quadrado 
LADO = 100  #tamanho do lado do quadrado
VELOCIDADE = 2 #velocidade do objeto sendo movimentado na tela


def desenha_arena():
    """pinta a cor de fundo e desenha as bordas da tela"""
    tela.fill(COR_FUNDO)
    pygame.draw.rect(tela, MARROM, ((BORDA,BORDA),(LARGURA_TELA-BORDA*2,ALTURA_TELA-BORDA*2)), 1)


# ** -------------------------------------------------------------
def desenha_figura(x, y, imagem):
    """desenha a figura na coordenada x, y passada como entrada"""
    #pygame.draw.rect(tela, VERMELHO, (x, y, LADO, LADO))
    tela.blit(imagem, (x, y))
# ** -------------------------------------------------------------
   

def move_figura(x, y, direcao):
    """
    retorna a próxima coordenada x,y em que a figura deve ser desenhada e
    a direção para onde deve ser movida, considerando as coordenadas x,y atuais
    e a direção atual, passadas como entrada
    """
    if direcao == 'direita':
        x += VELOCIDADE
        if x >= (LARGURA_TELA - BORDA - LADO): #bateu na borda direita? - muda direção para baixo
            x = (LARGURA_TELA - BORDA - LADO)
            direcao = 'baixo'
    elif direcao == 'baixo':
        y += VELOCIDADE
        if y >= (ALTURA_TELA - BORDA - LADO): #bateu na borda inferior? - muda direção para esquerda
            y = (ALTURA_TELA - BORDA - LADO)
            direcao = 'esquerda'
    elif direcao == 'esquerda': 
        x -= VELOCIDADE
        if x <= BORDA: #bateu na borda esquerda? - muda direção para cima
            x = BORDA
            direcao = 'cima'
    elif direcao == 'cima': 
        y -= VELOCIDADE
        if y <= BORDA: #bateu na borda superior? - muda direção para direita
            y = BORDA
            direcao = 'direita'
    
    return x, y, direcao
        
# Função principal
def main():
    pygame.init()
    global tela  # ** para que a janela do jogo será tratada com variável global    
 
    FPSCLOCK = pygame.time.Clock()
 
    # ** -------------------------------------------------------------
    #cria um objeto do tipo imagem, a partir de um jpg 
    obj_logo = pygame.image.load('logo_100x100.jpg')
    # ** -------------------------------------------------------------

    #cria a janela do jogo 
    tela = pygame.display.set_mode((LARGURA_TELA,ALTURA_TELA))
    pygame.display.set_caption('Move Logo') # ** põe o título na janela

    figuraX = BORDA     #controla a posição X da figura (começa de x=20)
    figuraY = BORDA     #controla a posição Y da figura (começa de y=20)
    direcao = "direita" #controla a direção da figura (começa indo para direita)

    desenha_arena()
    # ** -------------------------------------------------------------
    desenha_figura(figuraX, figuraY, obj_logo)
    # ** -------------------------------------------------------------
    
    #2-seção "game loop" ----------------------------
    terminou = False
    while not terminou: #Loop principal do jogo
        #3-seção de tratamento de eventos 
        for event in pygame.event.get():
            if event.type == QUIT:
                terminou = True
        
        #obtem a próxima posição x, y da figura e a próxima direção para onde deve ir
        figuraX, figuraY, direcao = move_figura(figuraX, figuraY, direcao)
        
        #redesenha a arena (pinta a tela com a cor de fundo e desenha as bordas)
        desenha_arena()
        
        #redesenha a figura na próxima posição correta
        # ** -------------------------------------------------------------
        desenha_figura(figuraX, figuraY, obj_logo)
        # ** -------------------------------------------------------------
        
        #4-atualização da tela do jogo 
        pygame.display.update()
        FPSCLOCK.tick(FPS)

    #---- fim do game loop ---------------------------
    # Finaliza a janela do jogo
    pygame.display.quit()
    # Finaliza o pygame
    pygame.quit()
    sys.exit()


if __name__=='__main__': # ** para chamar a função principal
    main()


