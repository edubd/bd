# 1-seção de configuração e definição de variáveis, classes etc.
import pygame
pygame.init()
largura_tela = 640; altura_tela = 480

tela = pygame.display.set_mode((largura_tela, altura_tela))

# 2-seção game loop -----------------------------
terminou = False
while not terminou:    
    # 3-seção de tratamento de eventos
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            terminou = True

    # 4-atualização da tela do jogo
    pygame.display.update()
# ---- fim do game loop: encerramos a pygame ---
pygame.display.quit()
pygame.quit()