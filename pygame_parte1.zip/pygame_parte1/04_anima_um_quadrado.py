# 1-seção de configuração e definição de variáveis
import pygame
pygame.init()
largura_tela = 640; altura_tela = 480
clock = pygame.time.Clock() #cria o relógio
FPS = 50                    #valor da FPS
COR_AMARELA = (255, 255, 51)
COR_PRETA = (0, 0, 0)

tela = pygame.display.set_mode((largura_tela, altura_tela))

def desenha_quadrado_amarelo(tela, x, y, lado):
    pygame.draw.rect(tela, COR_AMARELA, (x, y, lado, lado))
    
#define o lado do quadrado e as coordenadas x, y iniciais
lado=50; x=0; y=100; 

# 2-seção game loop -----------------------------
terminou = False
while not terminou:    
    # 3-seção de tratamento de eventos
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            terminou = True
            
    #--- animação do quadrado ----
    tela.fill(COR_PRETA) #apaga a tela (neste caso, pinta de preto)        
    desenha_quadrado_amarelo(tela, x, y, lado) #desenha o quadrado na posição x,y
    if (x < largura_tela - lado): #incrementa o valor de x,
                                  #se quadrado ainda não chegou no fim da tela
        x += 1
    #------------------------------

    # 4-atualização da tela do jogo
    clock.tick(FPS) #chama o método tick() para implementar a FPS
    pygame.display.update()
#---- fim do game loop: encerramos a pygame ---
pygame.display.quit()
pygame.quit()